Common module for project_m.
