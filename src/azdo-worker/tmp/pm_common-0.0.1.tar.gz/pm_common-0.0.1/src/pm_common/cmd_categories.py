from enum import Enum


class CmdCategories(Enum):
    GATHER = "GATHER"
    STRUCTURE = "STRUCTURE"
    EXT = "EXT"
    PERSIST = "PERSIST"
